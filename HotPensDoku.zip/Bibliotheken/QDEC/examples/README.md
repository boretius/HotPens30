These examples are designed to gradually move from basic usage
to more advanced usage.

Code in each sample is intentionally nearly identical.
Use of "diff" tools can highlight what changes between
examples.  This helps easily understand the steps needed
to use the more advanced methods, such as interrupts.
